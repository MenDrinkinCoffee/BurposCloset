### 1.0.0
- Suits added:
  - Jar jar banks aka jar jar binks
- 1.0.0 for no real reason, might not add much after this
### 0.0.16
- Suits added:
  - The Grimace
### 0.0.16
- Suits added:
  - The Mask
### 0.0.15
- Suits added:
  - Metal Jesus Rocks
### 0.0.14
- Added link to burpo's stream.
### 0.0.13
- Suits cleaned up:
  - Jeff Jarrett
  - Eternal Gamer 81
### 0.0.12
- Updated README
### 0.0.11
- Suits added:
  - Robocop
### 0.0.10
- Suits cleaned up:
  - Beavis
### 0.0.9
- Suits cleaned up:
  - Buff Minion
### 0.0.8
- New suits added:
  - Pickle Rick
  - Buff Minion
- Suits cleaned up:
  - Beavis
  - Butthead
### 0.0.7
- New suits added:
  - Tom Myers
  - Daniel Songer
### 0.0.6
- New suits added:
  - Beavis
  - Butthead
