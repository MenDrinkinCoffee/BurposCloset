### 0.0.6
- New suits added:
  - Beavis
  - Butthead
