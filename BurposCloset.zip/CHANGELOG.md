### 0.0.9
- Suits cleaned up:
  - Buff Minion
### 0.0.8
- New suits added:
  - Pickle Rick
  - Buff Minion
- Suits cleaned up:
  - Beavis
  - Butthead
### 0.0.7
- New suits added:
  - Tom Myers
  - Daniel Songer
### 0.0.6
- New suits added:
  - Beavis
  - Butthead
