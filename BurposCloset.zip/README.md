# Burpo's Closet
This is what the man wears.

## Unique suits
- Beavis
- Butthead
- Buff Minion
- Daniel Songer
- Eternal Gamer 81
- Jeff Jarrett WCW plush wrestler thing
- Kevin Smith
- Pickle Rick
- Quest64 Protagonist
- Robocop
- Tom Myers
## Suits included from other mods
- Aldi Suit from https://thunderstore.io/c/lethal-company/p/OurSapphireStar/Aldi_Suit/
- Peter Griffin from https://thunderstore.io/c/lethal-company/p/yeahimliam/Peter_Griffin_Suit/
- Lois Griffin from https://thunderstore.io/c/lethal-company/p/yeahimliam/Lois_Griffin_Suit/
- Stewie Griffin from https://thunderstore.io/c/lethal-company/p/yeahimliam/Stewie_Griffin_Suit/
